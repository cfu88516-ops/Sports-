package com.fn.sportslive

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B1020)
private val Panel = Color(0xFF151D31)
private val Green = Color(0xFF37E39A)
private val Muted = Color(0xFF9BA8C2)
private val White = Color(0xFFF5F7FF)

data class Match(
    val id: Int, val sport: String, val league: String,
    val home: String, val away: String, val score: String,
    val status: String, val time: String, val streamUrl: String = ""
)


private suspend fun fetchMatches(sport: String): List<Match> = withContext(Dispatchers.IO) {
    val url = URL("https://sportscore.com/api/widget/matches/?sport=$sport&limit=20&src=sports-live-by-fn")
    val connection = (url.openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        connectTimeout = 10000
        readTimeout = 10000
        setRequestProperty("Accept", "application/json")
    }
    try {
        if (connection.responseCode !in 200..299) return@withContext emptyList()
        val body = connection.inputStream.bufferedReader().use { it.readText() }
        val root = JSONObject(body)
        val array = root.optJSONArray("matches") ?: return@withContext emptyList()
        buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val home = item.optString("home", "Home")
                val away = item.optString("away", "Away")
                val homeScore = item.opt("home_score")?.toString()?.takeUnless { it == "null" } ?: "—"
                val awayScore = item.opt("away_score")?.toString()?.takeUnless { it == "null" } ?: "—"
                val rawStatus = item.optString("status", "upcoming")
                val statusText = item.optString("status_text", rawStatus)
                val live = rawStatus.equals("live", true) || statusText.contains("live", true)
                val finished = rawStatus.equals("finished", true)
                val status = when {
                    live -> "LIVE · $statusText"
                    finished -> "FINISHED"
                    else -> "UPCOMING"
                }
                val timestamp = item.optString("time", "")
                val timeLabel = if (timestamp.length >= 16) timestamp.replace("T", " ").take(16) else timestamp
                add(
                    Match(
                        id = (sport + "_" + item.optString("slug", "$home-$away")).hashCode(),
                        sport = if (sport == "cricket") "Cricket" else "Football",
                        league = item.optString("competition", if (sport == "cricket") "Cricket" else "Football"),
                        home = home,
                        away = away,
                        score = if (homeScore == "—" && awayScore == "—") "—" else "$homeScore - $awayScore",
                        status = status,
                        time = timeLabel.ifBlank { statusText }
                    )
                )
            }
        }
    } finally {
        connection.disconnect()
    }
}


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SportsLiveApp() }
    }
}

@Composable
fun SportsLiveApp() {
    var tab by remember { mutableStateOf("Home") }
    var matches by remember { mutableStateOf<List<Match>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var apiError by remember { mutableStateOf(false) }
    var favorites by remember { mutableStateOf(setOf<String>()) }
    var selected by remember { mutableStateOf<Match?>(null) }

    LaunchedEffect(Unit) {
        while (true) {
            loading = matches.isEmpty()
            val result = runCatching {
                fetchMatches("football") + fetchMatches("cricket")
            }
            if (result.isSuccess) {
                matches = result.getOrDefault(emptyList())
                apiError = matches.isEmpty()
            } else {
                apiError = true
            }
            loading = false
            delay(60_000)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Green, background = Bg, surface = Panel,
        onBackground = White, onSurface = White
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column {
                Header()
                if (selected != null) {
                    MatchDetails(
                        match = selected!!,
                        isFavorite = favorites.contains(selected!!.home),
                        onFavorite = {
                            favorites = if (favorites.contains(selected!!.home))
                                favorites - selected!!.home else favorites + selected!!.home
                        },
                        onBack = { selected = null }
                    )
                } else {
                    when (tab) {
                        "Football" -> MatchList(matches.filter { it.sport == "Football" }, favorites,
                            { favorites = toggle(favorites, it.home) }, { selected = it })
                        "Cricket" -> MatchList(matches.filter { it.sport == "Cricket" }, favorites,
                            { favorites = toggle(favorites, it.home) }, { selected = it })
                        "Favorites" -> MatchList(matches.filter { favorites.contains(it.home) }, favorites,
                            { favorites = toggle(favorites, it.home) }, { selected = it })
                        "Schedule" -> ScheduleScreen(matches)
                        else -> HomeScreen(
                            matches = matches, favorites = favorites,
                            onFavorite = { favorites = toggle(favorites, it.home) },
                            onSelect = { selected = it },
                            onSport = { tab = it },
                            loading = loading, apiError = apiError
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    NavigationBar(containerColor = Panel, contentColor = White) {
                        listOf(
                            Triple("Home", Icons.Filled.Home, "Home"),
                            Triple("Football", Icons.Filled.SportsSoccer, "Football"),
                            Triple("Cricket", Icons.Filled.SportsCricket, "Cricket"),
                            Triple("Favorites", Icons.Filled.Star, "Favorites"),
                            Triple("Schedule", Icons.Filled.CalendarMonth, "Schedule")
                        ).forEach { (label, icon, destination) ->
                            NavigationBarItem(
                                selected = tab == destination,
                                onClick = { tab = destination },
                                icon = { Icon(icon, contentDescription = label) },
                                label = { Text(label, fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Green,
                                    selectedTextColor = Green,
                                    indicatorColor = Color(0xFF25364A),
                                    unselectedIconColor = Muted,
                                    unselectedTextColor = Muted
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun toggle(old: Set<String>, team: String): Set<String> =
    if (old.contains(team)) old - team else old + team

@Composable
fun Header() {
    Row(
        Modifier.fillMaxWidth().background(Bg).padding(horizontal = 20.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).background(Green, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Bg, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("SPORTS LIVE", color = White, fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            Text("BY FN  •  FOOTBALL & CRICKET", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
        }
        Icon(Icons.Filled.NotificationsNone, contentDescription = "Notifications", tint = Green)
    }
}

@Composable
fun HomeScreen(
    matches: List<Match>, favorites: Set<String>,
    onFavorite: (Match) -> Unit, onSelect: (Match) -> Unit, onSport: (String) -> Unit,
    loading: Boolean, apiError: Boolean
) {
    LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Column(Modifier.fillMaxWidth().background(
                androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF183B39), Color(0xFF20294C))),
                RoundedCornerShape(22.dp)
            ).padding(20.dp)) {
                Text("YOUR SPORTS HUB", color = Green, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                Spacer(Modifier.height(8.dp))
                Text("Every match.\nOne place.", color = White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 35.sp)
                Spacer(Modifier.height(8.dp))
                Text("Scores, fixtures and official watch links.", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SportPill("⚽ Football") { onSport("Football") }
                    SportPill("🏏 Cricket") { onSport("Cricket") }
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(12.dp)) {
                Text(
                    when {
                        loading -> "Connecting to live sports data…"
                        apiError -> "Could not load scores. Check your internet and try again in about a minute."
                        else -> "Live data connected · refreshes every 60 seconds"
                    },
                    color = if (apiError) Color(0xFFFFB86B) else Green,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(4.dp))
                Text("Scores by SportScore · sportscore.com", color = Muted, fontSize = 10.sp)
            }
        }
        item { SectionTitle("LIVE NOW", "Follow the action") }
        if (matches.none { it.status.contains("LIVE") }) {
            item {
                Text(
                    if (loading) "Loading live matches…" else "No live matches returned right now.",
                    color = Muted, fontSize = 12.sp
                )
            }
        }
        items(matches.filter { it.status.contains("LIVE") }) { match ->
            MatchCard(match, favorites.contains(match.home), { onFavorite(match) }, { onSelect(match) })
        }
        item { SectionTitle("UPCOMING", "Don't miss a match") }
        if (matches.none { it.status == "UPCOMING" }) {
            item { Text("No upcoming fixtures in the current live/recent feed.", color = Muted, fontSize = 12.sp) }
        }
        items(matches.filter { it.status == "UPCOMING" }) { match ->
            MatchCard(match, favorites.contains(match.home), { onFavorite(match) }, { onSelect(match) })
        }
        item {
            Text("Demo scores are sample data. Connect a live sports data provider to show real-time scores.",
                color = Muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 6.dp))
        }
    }
}

@Composable
fun SportPill(text: String, onClick: () -> Unit) {
    Surface(color = Color(0xFF29364A), shape = RoundedCornerShape(50), modifier = Modifier.clickable { onClick() }) {
        Text(text, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp), color = White, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun SectionTitle(title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
        if (title == "LIVE NOW") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).background(Color(0xFFFF4D67), CircleShape))
                Spacer(Modifier.width(5.dp))
                Text("LIVE", color = Color(0xFFFF6B7D), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun MatchList(matches: List<Match>, favorites: Set<String>, onFavorite: (Match) -> Unit, onSelect: (Match) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { SectionTitle(if (matches.firstOrNull()?.sport == "Cricket") "CRICKET" else "FOOTBALL", "Scores and fixtures") }
        if (matches.isEmpty()) {
            item {
                Text("No favorite matches yet. Tap the star on a match to save it.", color = Muted, modifier = Modifier.padding(top = 24.dp))
            }
        }
        items(matches) { match -> MatchCard(match, favorites.contains(match.home), { onFavorite(match) }, { onSelect(match) }) }
    }
}

@Composable
fun MatchCard(match: Match, isFavorite: Boolean, onFavorite: () -> Unit, onSelect: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).clickable { onSelect() }.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(match.league.uppercase(), color = Muted, fontSize = 10.sp, letterSpacing = 1.sp, modifier = Modifier.weight(1f))
            if (match.status.contains("LIVE")) {
                Text(match.status, color = Color(0xFFFF667B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            } else {
                Text(match.status, color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            IconButton(onClick = onFavorite, modifier = Modifier.size(30.dp)) {
                Icon(if (isFavorite) Icons.Filled.Star else Icons.Filled.StarBorder, contentDescription = "Favorite", tint = if (isFavorite) Green else Muted, modifier = Modifier.size(19.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(match.home, color = White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(8.dp))
                Text(match.away, color = White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(match.score, color = White, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
                Spacer(Modifier.height(6.dp))
                Text(match.time, color = Muted, fontSize = 10.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.PlayCircle, contentDescription = null, tint = Green, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Match details & watch options", color = Green, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Muted)
        }
    }
}

@Composable
fun ScheduleScreen(matches: List<Match>) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { SectionTitle("MATCH SCHEDULE", "Upcoming fixtures and live matches") }
        if (matches.isEmpty()) {
            item { Text("No match data available yet. Check your internet connection.", color = Muted) }
        }
        items(matches.sortedBy { if (it.status == "UPCOMING") 1 else 0 }) { match ->
            MatchCard(match, false, {}, {})
        }
        item { Text("Fixture list is sample data until a real sports data feed is connected.", color = Muted, fontSize = 11.sp) }
    }
}

@Composable
fun MatchDetails(match: Match, isFavorite: Boolean, onFavorite: () -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    var streamUrl by remember(match.id) { mutableStateOf(match.streamUrl) }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("‹  Back", color = Green, fontSize = 16.sp, modifier = Modifier.clickable { onBack() }.padding(vertical = 8.dp))
        Spacer(Modifier.height(12.dp))
        Text(match.league.uppercase(), color = Muted, fontSize = 11.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(12.dp))
        Text("${match.home}  vs  ${match.away}", color = White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(10.dp))
        Text(match.score, color = Green, fontSize = 34.sp, fontWeight = FontWeight.Black)
        Text("${match.status}  •  ${match.time}", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(20.dp))
        OutlinedButton(onClick = onFavorite, modifier = Modifier.fillMaxWidth()) {
            Icon(if (isFavorite) Icons.Filled.Star else Icons.Filled.StarBorder, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(if (isFavorite) "Saved to Favorites" else "Add to Favorites")
        }
        Spacer(Modifier.height(24.dp))
        Text("OFFICIAL LIVE STREAM", color = White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(6.dp))
        Text("Paste a stream URL you own or are licensed to use. No unauthorized broadcasts are included.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = streamUrl, onValueChange = { streamUrl = it },
            label = { Text("https://…") }, placeholder = { Text("Official broadcaster link") },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Green, focusedLabelColor = Green,
                unfocusedBorderColor = Color(0xFF3B4860), unfocusedTextColor = White
            )
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                val url = streamUrl.trim()
                if (url.startsWith("https://") || url.startsWith("http://")) {
                    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Bg)
        ) {
            Icon(Icons.Filled.PlayArrow, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text("OPEN OFFICIAL STREAM", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(14.dp))
        Text("Note: stream links entered here are temporary in this starter version. A backend can be added to save links and fetch real scores.", color = Muted, fontSize = 11.sp)
    }
}
