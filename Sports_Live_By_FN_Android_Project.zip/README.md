# Sports Live By FN — Android starter project

## Included
- Kotlin + Jetpack Compose Android app with dark UI
- Football and cricket tabs
- Live/recent match feed fetched from SportScore public API
- Refreshes about every 60 seconds while app is open
- Favorites, match details, schedule screen
- User can open an HTTPS/HTTP official stream URL they are authorized to use

## Live score API
Uses the no-key public endpoints:
- `https://sportscore.com/api/widget/matches/?sport=football&limit=20&src=sports-live-by-fn`
- `https://sportscore.com/api/widget/matches/?sport=cricket&limit=20&src=sports-live-by-fn`

Provider docs: https://sportscore.com/developers/api/

The free attribution tier requires a visible, dofollow “Powered by SportScore” link on pages using the data. This starter shows “Scores by SportScore · sportscore.com” in-app; review the provider's current terms and ensure the attribution meets their requirements before public release. API availability and coverage are not guaranteed.

## Important limitations
- This starter fetches live/recent matches; it is not a complete future fixture calendar.
- Score feed fields/coverage can change; verify against the provider documentation.
- Stream links are entered per match and are not saved in this starter.
- Favorites are currently in-memory and reset when the app process restarts.
- For production, add persistent storage, retries/backoff, a backend if required, and verify the API provider's licence/attribution terms.

## Build APK
1. Install current stable Android Studio and Android SDK.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.
